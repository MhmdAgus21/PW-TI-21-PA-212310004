<footer style="height: 400px; background-color: #30318C; padding: 50px">
<div class="row text-white">
    <div class="col-md-6">
        <img src="/assets/img/logo2.png">
        <p class="fw-bold pt-5">HARPAS KESATUAN</p>
        <p>Jl. Rangga Gading No.01, Gudang,<br> Kecamatan Bogor Tengah, Kota Bogor, Jawa<br> Barat 16123</p>
    </div>
    <div class="col-md-3">
        <p class="fw-bold ms-4 ps-2">FEATURES</p>
        <ul style="list-style-type: none">
            <li>Home</li>
            <li>About Us</li>
            <li>Event</li>
            <li>Services</li>
            <li>Articles</li>
            <li>Contact Us</li>
        </ul>
    </div>
    <div class="col-md-3">
    <p class="fw-bold">OUR SOCIAL MEDIA</p>
    <img src="/assets/img/instagram.png" style="width: 30px" class="me-3"><img src="/assets/img/youtube.png" style="width: 30px" class="me-3"><img src="/assets/img/phone.png" style="width: 30px" class="me-3">
    </div>
</div>

<div class="row">
    <div class="col-md-12 text-center">
        <p style="color: #D9D9D9">Copyright &copy 2023 Harpas Kesatuan</p>
    </div>
</div>
</footer>