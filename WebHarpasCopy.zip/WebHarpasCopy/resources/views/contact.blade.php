@extends('templates.layouts')
@section('content')
<div class="d-flex align-items-auto p-0 my-0 text-white bg-purple rounded rounded-top rounded-bottom shadow-sm" style="padding-bottom: 10px;">
    <img class="me-0 rounded" src="./assets/img/banner.png" width="90%" style="margin: 0 80px;">
    <div class="lh-1 align-self-start"></div>
</div>
<div class="container-fluid" style="margin: 40px 80px;">
    <div class="row">
        <div class="col-md-4">
            <div class="card border-secondary mb-3 h-100" style="padding: 40px;">
                <div class="d-flex flex-column align-items-start">
                    <p class="text-margin" style="font-size: 28px; color: black;">Feel Free to Contact Our Community</p>
                    <p class="text-margin" style="font-size: 24px; color: gray;">@harpas.kst</p>
                    <p class="text-margin" style="font-size: 24px; color: gray;">Harpas Kesatuan</p>
                    <p class="text-margin" style="font-size: 24px; color: gray;">0851-5682-3895</p>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="card border-secondary mb-3 h-100" style="padding: 40px;">
                <div class="d-flex flex-column align-items-end">
                    <p class="text-margin mb-1" style="font-size: 24px; color: gray; margin-right: 80px;">Jl. Rangga Gading No.01, Gudang, Kecamatan Bogor Tengah, Kota Bogor, Jawa Barat 16123</p>
                </div>
                <div class="row" style="margin-top:40px">
                    <div class="col-md-12">
                        <div class="embed-responsive embed-responsive-16by9 rounded" style="border-radius: 10px;">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15864.536019861436!2d106.7892862197753!3d-6.605239395301828!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69c5c191f0a555%3A0xe6e757cf32829f41!2sIBI%20KESATUAN%20BOGOR!5e0!3m2!1sen!2sid!4v1623911143930!5m2!1sen!2sid" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



@endsection