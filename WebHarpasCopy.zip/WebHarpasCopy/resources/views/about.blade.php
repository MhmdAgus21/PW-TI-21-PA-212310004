@extends('templates.layouts')
@section('content')
<div class="row pt-5">
    <div class="col-md-12 text-center">
        <img src="/assets/img/about-background.svg">
    </div>
</div>

<div class="row justify-content-center pt-3 shadow mt-5 text-center border rounded">
    <div class="col-md-7">
        <h1 class="fw-bold mb-4" style="color:#321641">History</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi semper urna sed ipsum eleifend, eu pharetra augue aliquam. Donec non pellentesque quam. Pellentesque a felis ultrices, dapibus eros a, viverra dui. Ut nec lacus tristique, scelerisque arcu nec, posuere justo. Pellentesque accumsan vehicula mauris eu tristique. Nulla facilisi. Nulla facilisi. Fusce eu mi in leo egestas scelerisque et sed velit. Mauris sodales vestibulum dui faucibus accumsan. Vestibulum sollicitudin lacus quis porta placerat. Curabitur ex mi, fringilla sit amet maximus ut, efficitur nec erat. Aliquam at sapien tristique, blandit quam eu, tempor lorem. Phasellus vitae ex tellus. Aliquam vel consectetur magna, sit amet dapibus diam. Sed id dapibus leo, sit amet porttitor elit. In bibendum vitae magna eget congue.</p>
    </div>
</div>

<div class="row mt-5 justify-content-center">
    <div class="col-md-12 text-center mb-5">
        <h1 class="fw-bold" style="color:#321641">Vision & Mission</h1>
    </div>
    <div class="col-md-4 text-white me-5 rounded shadow p-5" style="height: 400px; background-color: #30318C">
        <h1>VISION</h1>
    </div>
    <div class="col-md-4 text-white rounded shadow p-5" style="height: 400px; background-color: #6D6BB5">
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi semper urna sed ipsum eleifend, eu pharetra augue aliquam. Donec non pellentesque quam. Pellentesque a felis ultrices, dapibus eros a, viverra dui. Ut nec lacus tristique, scelerisque arcu nec, posuere justo. Pellentesque accumsan vehicula mauris eu tristique. Nulla facilisi. Nulla facilisi. Fusce eu mi in leo egestas scelerisque et sed velit. Mauris sodales vestibulum dui faucibus accumsan.</p>
    </div>
</div>

<div class="row mt-5 justify-content-center text-center">
    <div class="col-md-12 text-center mb-5">
        <h1 class="fw-bold" style="color:#321641">OUR DIVISION</h1>
    </div>
    <div class="col-md-4 mb-5">
        <img src="/assets/img/division1.svg" class="me-3">
    </div>
    <div class="col-md-4 mb-5">
        <img src="/assets/img/division1.svg" class="me-3">
    </div>
    <div class="col-md-4 mb-5">
        <img src="/assets/img/division1.svg" class="me-3">
    </div>
    <div class="col-md-4 mb-5">
        <img src="/assets/img/division1.svg" class="me-3">
    </div>
    <div class="col-md-4 mb-5">
        <img src="/assets/img/division1.svg" class="me-3">
    </div>
    <div class="col-md-4 mb-5">
        <img src="/assets/img/division1.svg" class="me-3">
    </div>
</div>

<div class="row mt-5 justify-content-center text-center">
    <div class="col-md-12">
        <h1 class="fw-bold" style="color:#321641">OUR TEAM</h1>
    </div>
</div>

<div class="row mt-5 justify-content-center text-center mb-5">
    <div class="col-md-5 mb-4 me-5">
        <img src="/assets/img/ketua.svg" alt="Ketua"><br>
        <span class="fw-bold mt-3">Bagas Ferdiansyah</span><br>
        <span>Ketua Umum</span>
    </div>
    <div class="col-md-5 mb-4 me-5">
        <img src="/assets/img/wakilketua.svg" alt="Ketua"><br>
        <span class="fw-bold mt-3">Bella Arika Semeru</span><br>
        <span>Wakil Ketua Umum</span>
    </div>
    <div class="col-md-5 mb-4 me-5">
        <img src="/assets/img/sekretaris1.svg" alt="Ketua"><br>
        <span class="fw-bold mt-3">Siti Yasmin Salsabila Sunantoputri</span><br>
        <span>Sekretaris Umum 1</span>
    </div>
    <div class="col-md-5 mb-4 me-5">
        <img src="/assets/img/sekretaris2.svg" alt="Ketua"><br>
        <span class="fw-bold mt-3">Wanaputri Dwi Adinda</span><br>
        <span>Sekretaris Umum 2</span>
    </div>
    <div class="col-md-5 mb-4 me-5">
        <img src="/assets/img/bendahara1.svg" alt="Ketua"><br>
        <span class="fw-bold mt-3">Hana Amelia Safitri</span><br>
        <span>Bendahara Umum 1</span>
    </div>
    <div class="col-md-5 mb-4 me-5">
        <img src="/assets/img/bendahara2.svg" alt="Ketua"><br>
        <span class="fw-bold mt-3">Feby Analce Margaretha</span><br>
        <span>Bendahara Umum 2</span>
    </div>
</div>
@endsection