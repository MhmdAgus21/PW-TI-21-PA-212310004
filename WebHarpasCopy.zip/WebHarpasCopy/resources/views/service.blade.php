@extends('templates.layouts')
@section('content')
<div class="row pt-5">
    <div class="col-md-12 text-center">
        <img src="/assets/img/service-background.svg">
    </div>
</div>

<div class="row justify-content-center pt-5">
    <div class="col-md-5 text-start">
        <h1>Band</h1>
        <span>Kesatuan Harpas band</span><br>
        <span class="text-secondary">Bianglala, ulala, tralala, trilili</span><br><br>

        <span>Services</span><br>
        <span class="text-secondary">Duration max 6 Hours</span><br>
        <span class="text-secondary">2 Vocalis</span><br>
        <span class="text-secondary">1 Gitaris</span><br>
        <span class="text-secondary">1 spanianist</span><br>
        <span class="text-secondary">Bassist</span><br>
        <span class="text-secondary">Pricelist</span>
        <p class="text-primary fw-bold">Start From IDR 500.000,00</p>
    </div>
    <div class="col-md-5 text-end">
        <img src="/assets/img/band-bg.svg" alt="" style="width:70%"> 
    </div>
</div>

    <div class="row justify-content-center pt-5">
        <div class="col-md-5 text-start">
            <img src="/assets/img/choir-bg.svg" alt=""  style="width:70%">
        </div>
        <div class="col-md-5" style="padding-left: 150px">
            <h1>Choir</h1>
            <span>Kesatuan Harpas Band</span><br>

            <span class="text-secondary">Good choir</span><br><br>

           <span >Services</span><br>
           <span class="text-secondary">Duration max 3 Hours</span><br>
           <span class="text-secondary">15 Member</span><br>
           <span class="text-secondary">5 songs</span><br>
           <span class="text-secondary">Pricelist</span><br>
           <span class="text-primary fw-bold">Start From IDR 500.000,00</span><br>
        </div>
    </div>

    <div class="row justify-content-center pt-5">
    <div class="col-md-5 text-start">
        <h1>Modern Dance</h1>
        <span>Kesatuan Harpas band</span><br>
        <span class="text-secondary">Bianglala, ulala, tralala, trilili</span><br><br>

        <span>Services</span><br>
        <span class="text-secondary">Duration max 2 Hours</span><br>
        <span class="text-secondary">5 Member in one grup</span><br>
        <span class="text-secondary">Pricelist</span>
        <p class="text-primary fw-bold">Start From IDR 500.000,00</p>
    </div>
    <div class="col-md-5 text-end">
        <img src="/assets/img/modern-dance.svg" alt="" style="width:70%"> 
    </div>
</div>


<div class="row justify-content-center pt-5">
        <div class="col-md-5 text-start">
            <img src="/assets/img/traditional-dance.svg" alt=""  style="width:70%">
        </div>
        <div class="col-md-5" style="padding-left: 150px">
        <h1>Traditional Dance</h1>
            <span>Kesatuan Harpas Band</span><br>

            <span class="text-secondary">Dance Fun</span><br><br>

           <span >Services</span><br>
           <span class="text-secondary">Duration max 3 Hours</span><br>
           <span class="text-secondary">2-5 Member</span><br>
           <span class="text-secondary">Costom songs</span><br><br>
           <span class="text-secondary">Pricelist</span><br>
           <span class="text-primary fw-bold">Start From IDR 500.000,00</span><br>
        </div>
    </div>


    <div class="row justify-content-center pt-5">
    <div class="col-md-5 text-start">
        <h1>Photographer</h1>
        <span>Kesatuan Harpas band</span><br>
        <span class="text-secondary">Alfan, Tesla, Nicole</span><br><br>

        <span>Services</span><br>
        <span class="text-secondary">Duration max 6 Hours</span><br>
        <span class="text-secondary">Free Soft Copy</span><br>
        <span class="text-secondary">Photo and Video</span><br>
        <span class="text-secondary">Available on any event</span><br><br>
        <span class="text-secondary">Pricelist</span>
        <p class="text-primary fw-bold">Start From IDR 500.000,00</p>
    </div>
    <div class="col-md-5 text-end mb-3">
        <img src="/assets/img/photographer-bg.svg" alt="" style="width:70%"> 
    </div>
</div>


@endsection