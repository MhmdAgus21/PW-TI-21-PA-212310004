@extends('templates.layouts')
@section('content')
<div class="row pt-5">
    <div class="col-md-12 text-center">
        <img src="/assets/img/article-background.svg">
    </div>
</div>

<div class="row px-5 mx-4 mt-4">
    <div class="col-md-12">
        <h2>Blog Harpas</h2>
    </div>
</div>

<div class="row px-5 mx-4 mt-4">
    <div class="col-md-5">
        <input type="text" class="border rounded-pill p-3 d-inline-block w-100" placeholder="Hey! What you are looking for?">
    </div>
    <div class="col-md-2">
        <button class="btn btn-primary p-3 rounded-pill w-100">Seacrh</button>
    </div>
</div>

<div class="row px-5 mx-4 mt-4">
    <div class="col-md-12">
        <h2>Category</h2>
    </div>
    <div class="col-md-12 mt-4">
        <button class="btn btn-white shadow border p-3 rounded-pill me-4 fw-bold" style="width:130px; color: #082745">Event</button>
        <button class="btn btn-white shadow border p-3 rounded-pill me-4 fw-bold" style="width:130px; color: #082745">MMK</button>
        <button class="btn btn-white shadow border p-3 rounded-pill me-4 fw-bold" style="width:130px; color: #082745">Seacrh</button>
        <button class="btn btn-white shadow border p-3 rounded-pill me-4 fw-bold" style="width:130px; color: #082745">Seacrh</button>
        <button class="btn btn-white shadow border p-3 rounded-pill me-4 fw-bold" style="width:130px; color: #082745">Seacrh</button>
        <button class="btn btn-white shadow border p-3 rounded-pill me-4 fw-bold" style="width:130px; color: #082745">Seacrh</button>
    </div>
</div>


<div class="row px-5 mx-4 mt-4">
    <div class="col-md-4 mb-5 ">
        <div class="card" style="width: 18rem;">
        <img src="/assets/img/post-background.svg" class="card-img-top">
        <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <hr class="border border-dark">
            <a href="#" class="text-decoration-none">View more</a>
        </div>
        </div>
    </div>
    <div class="col-md-4 mb-5 ">
        <div class="card" style="width: 18rem;">
        <img src="/assets/img/post-background.svg" class="card-img-top">
        <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <hr class="border border-dark">
            <a href="#" class="text-decoration-none">View more</a>
        </div>
        </div>
    </div>
    <div class="col-md-4 mb-5 ">
        <div class="card" style="width: 18rem;">
        <img src="/assets/img/post-background.svg" class="card-img-top">
        <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <hr class="border border-dark">
            <a href="#" class="text-decoration-none">View more</a>
        </div>
        </div>
    </div>
    <div class="col-md-4 mb-5 ">
        <div class="card" style="width: 18rem;">
        <img src="/assets/img/post-background.svg" class="card-img-top">
        <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <hr class="border border-dark">
            <a href="#" class="text-decoration-none">View more</a>
        </div>
        </div>
    </div>
    <div class="col-md-4 mb-5 ">
        <div class="card" style="width: 18rem;">
        <img src="/assets/img/post-background.svg" class="card-img-top">
        <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <hr class="border border-dark">
            <a href="#" class="text-decoration-none">View more</a>
        </div>
        </div>
    </div>
    <div class="col-md-4 mb-5 ">
        <div class="card" style="width: 18rem;">
        <img src="/assets/img/post-background.svg" class="card-img-top">
        <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <hr class="border border-dark">
            <a href="#" class="text-decoration-none">View more</a>
        </div>
        </div>
    </div>
</div>

<div class="row px-5 mx-4 mt-4">
    <div class="col-md-12 text-center mb-4">
        <a href="#" class="btn shadow px-5 py-2 text-white fw-bold" style="background-color: #30318C">View More</a>
    </div>
</div>
@endsection